cd files/games/fishing0.1.9
chmod u+x fishing.run
./fishing.run
