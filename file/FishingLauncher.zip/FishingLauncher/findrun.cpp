#include <iostream>
#include <string>
#include <dirent.h>  // 包含处理目录的函数

using namespace std;

// 检查文件名是否以指定的后缀结束
bool hasExtension(const string& fileName, const string& extension) {
    if (fileName.length() >= extension.length()) {
        return (0 == fileName.compare(fileName.length() - extension.length(), extension.length(), extension));
    } else {
        return false;
    }
}

void listDirectoryContents(const string& dirName) {
    DIR *dir;            // 指向目录的指针
    struct dirent *entry; // 用于目录条目的结构

    dir = opendir(dirName.c_str()); // 尝试打开目录
    if (dir == nullptr) { // 检查目录是否成功打开
        perror("Failed to open directory");
        return;
    }

    cout << "Contents of directory " << dirName << " with .out and .sh extensions:" << endl;
    while ((entry = readdir(dir)) != nullptr) { // 遍历所有目录项
        string fileName = entry->d_name;
        if (hasExtension(fileName, ".out") || hasExtension(fileName, ".sh")) {
            cout << fileName << endl;
        }
    }
    closedir(dir); // 完成后关闭目录
}

int main() {
    string directoryPath = "."; // 指定目录路径
    listDirectoryContents(directoryPath);
    return 0;
}
