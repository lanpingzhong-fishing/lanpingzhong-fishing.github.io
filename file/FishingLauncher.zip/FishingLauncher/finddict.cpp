#include <iostream>
#include <string>
#include <dirent.h>  // 包含处理目录的函数

using namespace std;

void listDirectoriesOnly(const string& dirName) {
    DIR *dir;            // 指向目录的指针
    struct dirent *entry; // 用于目录条目的结构

    dir = opendir(dirName.c_str()); // 尝试打开目录
    if (dir == nullptr) { // 检查目录是否成功打开
        perror("Failed to open directory");
        return;
    }

    cout << "Directories in " << dirName << ":" << endl;
    while ((entry = readdir(dir)) != nullptr) { // 遍历所有目录项
        if (entry->d_type == DT_DIR) { // 检查是否为目录
            string entryName = entry->d_name;
            // 跳过 "." 和 ".." 条目
            if (entryName != "." && entryName != "..") {
                cout << entryName << endl;
            }
        }
    }
    closedir(dir); // 完成后关闭目录
}

int main() {
    string directoryPath = "files/games"; // 指定目录路径
    listDirectoriesOnly(directoryPath);
    return 0;
}
