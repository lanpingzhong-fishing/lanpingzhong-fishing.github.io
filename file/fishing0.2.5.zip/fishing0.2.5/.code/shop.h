#ifndef shop_defined
#define shop_defined
#include<iostream>
#include<string>
using std::string;
using std::to_string;
#include"variate.h"
#include"function.h"
namespace shop{
	inline void tool0(){
		if(variate::tool[0] == 1){
			clear();
			cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
			cout << "请输入密码: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 2281968572269345840ll){
				cout << "密码错误, 请重试: ";
				cout.flush();
				string mi;
				getline(mi);
				if(to_hash(mi) != 2281968572269345840ll){
					for(int i = 0; i < variate::tools; i++){
						variate::tool[i] = 0;
					}
					return;
				}
			}
			variate::tool[0] = 2;
		}
		clear();
		print("\033[31;1mshop0.开发者模式\033[m");
		print("1.上钩速度, 2.钓鱼收益, 3.脱钩概率, 4.清洁剂, 5.水族馆容量, 按esc退出。");
		char c;
		while((c = getch()) != '1' && c != '2' && c != '3' && c != '4' && c != '5'){
			if(c == 27){
				return;
			}
		}
		if(c == '1'){
			int le = variate::level;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "上钩速度:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < variate::max_level ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < variate::max_level){
						le++;
						break;
					}else if(c == 13){
						variate::level = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '2'){
			int le = variate::get_level;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "钓鱼收益:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < variate::max_level2 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < variate::max_level2){
						le++;
						break;
					}else if(c == 13){
						variate::get_level = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '3'){
			int le = variate::slip;
			while(true){
				clear();
				variate::slip /= 10;
				variate::slip *= 10;
				cout << "按a增加, 按d减少, 按enter保存, 按esc退出" << endl;
				cout << "脱钩概率:" << endl;
				cout << (le < 90 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << '%' << (le > 0 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le < 90){
						if(le >= 10){
							le += 10;
						}else if(le >= 5){
							le = 10;
						}else if(le >= 0){
							le += 1;
						}
						break;
					}else if(c == 'd' && le > 0){
						if(le > 10){
							le -= 10;
						}else if(le > 5){
							le = 5;
						}else if(le > 0){
							le -= 1;
						}
						break;
					}else if(c == 13){
						variate::slip = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '4'){
			int le = variate::cleaning_ball;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "清洁剂数量:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << (le < 1000 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						if(le <= 10){
							le--;
						}else if(le <= 100){
							le -= 10;
						}else{
							le -= 100;
						}
						break;
					}else if(c == 'd' && le < 1000){
						if(le < 10){
							le++;
						}else if(le < 100){
							le += 10;
						}else{
							le += 100;
						}
						break;
					}else if(c == 13){
						variate::cleaning_ball = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '5'){
			int le = variate::aqcnt;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "水族馆容量:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << (le < 50 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < 50){
						le++;
						break;
					}else if(c == 13){
						variate::aqcnt = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}
	}
	inline void tool1(){
		if(variate::tool[1] == 1){
			clear();
			cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
			cout << "请输入密码: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 7777707626182367997ll){
				cout << "密码错误, 请重试: ";
				cout.flush();
				string mi;
				getline(mi);
				if(to_hash(mi) != 7777707626182367997ll){
					for(int i = 0; i < variate::tools; i++){
						variate::tool[i] = 0;
					}
					return;
				}
			}
			variate::tool[1] = 2;
		}
		clear();
		print("\033[31;1mshop1.开发者模式\033[m");
		print("1.甩杆倍速, 2.升级大鱼概率, 按esc退出。");
		char c;
		while((c = getch()) != '1' && c != '2'){
			if(c == 27){
				return;
			}
		}
		if(c == '1'){
			int le = variate::stime;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "甩杆倍速:" << endl;
				cout << (le > 1 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < 10 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 1){
						le--;
						break;
					}else if(c == 'd' && le < 10){
						le++;
						break;
					}else if(c == 13){
						variate::stime = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '2'){
			int le = variate::bf;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "大鱼概率:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < 100 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le -= 5;
						break;
					}else if(c == 'd' && le < 100){
						le += 5;
						break;
					}else if(c == 13){
						variate::bf = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}
	}
	inline void shop0(){
		clear();
		print("1.升级上钩速度, 2.升级钓鱼收益, 3.脱钩概率, 4.购买清洁剂, 5.升级清洁剂, 6.升级水族馆容量, 7.返回。");
		print("上钩速度: ");
		if(variate::level == variate::max_level){
			print("    等级已满");
		}else{
			print("    当前平均时间: " + to_string((variate::mintime[variate::level] + variate::maxtime[variate::level]) >> 1) + (((variate::mintime[variate::level] + variate::maxtime[variate::level]) & 1) ? ".5" : "") + ", 升级后平均时间: " + to_string((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) >> 1) + (((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost[variate::level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("钓鱼收益: ");
		if(variate::get_level == variate::max_level2){
			print("    等级已满");
		}else{
			print("    当前平均收益: " + to_string((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) >> 1) + (((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) & 1) ? ".5" : "") + ", 升级后平均收益: " + to_string((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) >> 1) + (((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost2[variate::get_level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("脱钩概率: ");
		if(variate::slip == 0){
			print("    等级已满");
		}else{
			if(variate::slip > 10){
				variate::slip /= 10;
				variate::slip *= 10;
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 10) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 5){
				variate::slip = 10;
				print("    当前脱钩概率: 10%, 升级后脱钩概率: 5%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 1){
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 1) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else{
				print("    当前脱钩概率: 1%, 升级后脱钩概率: 0%");
				print("    升级花费: $500, 当前金币数量: $" + to_string(variate::money));
			}
		}
		print("清洁剂: ");
		print("    当前清洁剂个数: " + to_string(variate::cleaning_ball));
		print("    购买花费: $10, 当前金币数量: $" + to_string(variate::money));
		print("清洁效率: ");
		if(variate::cleaning_sub == 10){
			print("    等级已满");
		}else{
			print("    当前清洁效率: 一次降低" + to_string(variate::cleaning_sub) + "级, 升级后清洁效率: 一次降低" + to_string(variate::cleaning_sub + 1) + "级");
			print("    购买花费: $30, 当前金币数量: $" + to_string(variate::money));
		}
		print("水族馆容量: ");
		if(variate::aqcnt == 30){
			print("    等级已满");
		}else{
			print("    当前水族馆容量: " + to_string(variate::aqcnt) + "只, 升级后水族馆容量: " + to_string(variate::aqcnt + 2) + "只");
			print("    购买花费: $" + to_string((variate::aqcnt + 2) * 100) + ", 当前金币数量: $" + to_string(variate::money));
		}
		char type = 0;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::level == variate::max_level){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost[variate::level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost[++variate::level];
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::get_level == variate::max_level2){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost2[variate::get_level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost2[++variate::get_level];
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				if(variate::slip == 0){
					print("等级已满");
					break;
				}else if(variate::slip == 1){
					if(variate::money < 500){
						print("金钱不够");
						break;
					}else{
						variate::money -= 500;
						variate::slip = 0;
						print("购买成功");
						break;
					}
				}else{
					if(variate::money < 100){
						print("金钱不够");
						break;
					}else{
						variate::money -= 100;
						if(variate::slip > 10){
							variate::slip -= 10;
						}else if(variate::slip > 5){
							variate::slip = 5;
						}else if(variate::slip > 0){
							variate::slip -= 1;
						}
						print("购买成功");
						break;
					}
				}
			}else if(type == '4'){
				if(variate::money < 10){
					print("金钱不够");
					break;
				}else{
					variate::money -= 10;
					variate::cleaning_ball++;
					print("购买成功");
					break;
				}
			}else if(type == '5'){
				if(variate::cleaning_sub == 10){
					print("等级已满");
					break;
				}else if(variate::money < 30){
					print("金钱不够");
					break;
				}else{
					variate::money -= 30;
					variate::cleaning_sub++;
					print("购买成功");
					break;
				}
			}else if(type == '6'){
				if(variate::aqcnt == 30){
					print("等级已满");
					break;
				}else if(variate::money < (variate::aqcnt + 2) * 100){
					print("金钱不够");
					break;
				}else{
					variate::money -= (variate::aqcnt + 2) * 100;
					variate::aqcnt += 2;
					print("购买成功");
					break;
				}
			}else if(type == '7'){
				break;
			}else if(type == 127 && variate::tool[1] != 0){
				tool0();
				break;
			}
		}
	}
	inline void shop1(){
		clear();
		printa("这里是超级商店, 可以买一些特殊的商品。");
		clear();
		print("1.甩杆倍速, 2.升级大鱼概率, 3.返回。");
		print("甩杆倍速: ");
		if(variate::stime >= 10){
			print("    等级已满");
		}else{
			print("    当前倍速: " + to_string(variate::stime) + ", 升级后游戏倍速: " + to_string(variate::stime + 1));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		print("大鱼概率: ");
		if(variate::bf >= 60){
			print("    等级已满");
		}else{
			print("    当前大鱼概率: " + to_string(variate::bf) + ", 升级后大鱼概率" + to_string(variate::bf + 5));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::stime >= 10){
					print("等级已满");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::stime++;
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::bf >= 60){
					print("等级已满");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::bf += 5;
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				break;
			}else if(type == 127 && variate::tool[1] != 0){
				tool1();
				break;
			}
		}
	}
	inline void shop(){
		clear();
		print("1.普通商店, 2.超级商店, 3.退出。");
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				shop0();
				break;
			}else if(type == '2'){
				shop1();
				break;
			}else if(type == '3'){
				break;
			}
		}
	}
}
#endif
