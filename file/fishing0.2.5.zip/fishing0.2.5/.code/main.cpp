#include<iostream>
#include<sys/stat.h>
/*//2770
thinkpoint:
gjc:小猫钓鱼，增加鱼竿种类
jhc:和成下界合金碎片
*/
#include"variate.h"
#include"color.h"
#include"base64.h"
#include"fishing.h"
#include"shop.h"
#include"checkpoint.h"
#include"setting.h"
#include"function.h"
#include"story.h"
#include"first.h"
#include"error.h"
#include"egg.h"
#include"spin.h"
#include"surprise.h"
inline void tool(){
	if(variate::tool[2] != 2){
		clear();
		cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
		cout << "请输入密码: ";
		cout.flush();
		string mi;
		getline(mi);
		if(to_hash(mi) != 6719929333535458606){
			cout << "密码错误, 请重试: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 6719929333535458606){
				for(int i = 0; i < variate::tools; i++){
					variate::tool[i] = 0;
				}
				return;
			}
		}
	}
	variate::tool[2] = 2;
	clear();
	print("调试信息: ");
	print(checkpoint::de());
	print("\033[31;1mmain.开发者模式\033[m");
	print("1.金币数量, 2.关闭开发者模式, 3.封禁开发者模式, 按esc退出。");
	char c;
	while((c = getch()) != '1' && c != '2' && c != '3'){
		if(c == 27){
			return;
		}
	}
	if(c == '1'){
		int le = variate::money;
		while(true){
			clear();
			cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
			if(le <= 10){
			}else if(le <= 100){
				le /= 10;
				le *= 10;
			}else if(le <= 1000){
				le /= 100;
				le *= 100;
			}else if(le <= 10000){
				le /= 1000;
				le *= 1000;
			}else if(le <= 100000){
				le /= 10000;
				le *= 10000;
			}else if(le <= 1000000){
				le /= 100000;
				le *= 100000;
			}else{
				le = 1000000;
			}
			cout << "金币数量:" << endl;
			cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "$" << (le < 1000000 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
			while(true){
				char c = getch();
				if(c == 'a' && le > 0){
					if(le <= 10){
						le--;
					}else if(le <= 100){
						le -= 10;
					}else if(le <= 1000){
						le -= 100;
					}else if(le <= 10000){
						le -= 1000;
					}else if(le <= 100000){
						le -= 10000;
					}else if(le <= 1000000){
						le -= 100000;
					}
					break;
				}else if(c == 'd' && le < 1000000){
					if(le < 10){
						le++;
					}else if(le < 100){
						le += 10;
					}else if(le < 1000){
						le += 100;
					}else if(le < 10000){
						le += 1000;
					}else if(le < 100000){
						le += 10000;
					}else if(le < 1000000){
						le += 100000;
					}
					break;
				}else if(c == 13){
					variate::money = le;
					return;
				}else if(c == 27){
					return;
				}
			}
		}
	}else if(c == '2'){
		for(int i = 0; i < variate::tools; i++){
			variate::tool[i] = 1;
		}
	}else if(c == '3'){
		for(int i = 0; i < variate::tools; i++){
			variate::tool[i] = 0;
		}
	}
}
int main(){
	srand(time(0));
	system("mkdir checkpoint >/dev/null 2>&1");
	if(!directoryExists("checkpoint")){
		print("保存文件夹缺失, 请手动创建名为\"checkpoint\"的文件夹");
		system("stty echo cooked");
		exit(1);
	}
	#ifndef deb
	story();
	first::first();
	if(checkpoint::chp()){
		sleep(1);
		choose();
	}
	sleep(1);
	checkpoint::savechpnp(variate::name, false);
	#endif
	#ifdef deb
	variate::stime = 1000;
	variate::name = "a";
	checkpoint::readchpnp("a");
	#endif
	while(true){
		clear();
		print("1.开始钓鱼, 2.进入商店, 3.存档, 4.读档, 5.设置自动保存, 6.查看成就, 7.设置, 8.抽奖, 9.退出, 其他输入无效。");
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r' && type != 127 && type != 27){
				continue;
			}
			if(type == '1'){
				if(variate::tool[3] == 2 || error("fishing")){
					fishing::fishing_setup();
				}
				break;
			}else if(type == '2'){
				clear();
				shop::shop();
				break;
			}else if(type == '3'){
				clear();
				checkpoint::save();
				break;
			}else if(type == '4'){
				clear();
				checkpoint::read();
				break;
			}else if(type == '5'){
				clear();
				checkpoint::set_auto_save();
				break;
			}else if(type == '6'){
				clear();
				egg::egg();
				break;
			}else if(type == '7'){
				clear();
				setting::setting();
				break;
			}else if(type == '8'){
				clear();
				spin::spin();
				break;
			}else if(type == '9'){
				clear();
				return 0;
			}else if(type == 127 && variate::tool[2] != 0){
				tool();
				break;
			}else if(type == ' '){
				surprise::surprise();
				break;
			}
		}
		checkpoint::auto_save();
		checkpoint::savechpnp(variate::name, false);
		sleep(0.5);
	}
}
