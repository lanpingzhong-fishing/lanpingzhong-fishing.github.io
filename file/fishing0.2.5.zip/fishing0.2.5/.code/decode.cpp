#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<string>
using std::cin;
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::ifstream;
using std::ofstream;
using std::to_string;
#include"variate.h"
#include"function.h"
#include"checkpoint.h"
int main(){
	print("输入文件名");
	string name;
	getline(name, true);
	string s;
	{
		ifstream in("checkpoint/" + name);
		if(!in.good()){
			cout << "file can not found" << endl;
			return 0;
		}
		in >> s;
	}
	if(checkpoint::decode(s, false)){
		cout << "null ok" << endl;
		checkpoint::savechpnp(name);
		checkpoint::check();
		return 0;
	}
	// for(int i = 0; i < variate::tools; i++){
	// 	variate::tool[i] = 1;
	// }
	for(int i = 0; i <= 2106000; i++){
		base64 a(i);
		if(checkpoint::decode(a.decode(s), false)){
			cout << i << " ok" << endl;
			checkpoint::savechpnp(name);
			checkpoint::check();
			return 0;
		}
	}
	cout << "error" << endl;
}