#include<iostream>
using namespace std;
int main(){
    int a;
    while(cin >> a){
        cout << (char)a << endl;
    }
}