#include<hashtable.h>
#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<fstream>
#include<iomanip>
#include<ctime>
using std::cin;
using std::pair;
using std::setw;
using std::hash;
using std::string;
using std::ostream;
using std::istream;
using std::ifstream;
using std::ofstream;
using std::to_string;
int cols = 142, line = 21;
inline void clear(){
	system("clear");
}
namespace variate{
	int level = 0;
	const int max_level = 25;
	const int mintime[26] = {50, 40, 40, 40, 30, 30, 30, 30, 20, 20, 10, 9, 7, 5, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1};
	const int maxtime[26] = {100, 100, 90, 80, 80, 70, 60, 50, 50, 40, 40, 40, 40, 40, 40, 35, 30, 25, 20, 10, 5, 4, 4, 3, 3, 2};
	int get_level = 0;
	const int max_level2 = 29;
	const int maxget[30] = {20, 20, 20, 30, 30, 40, 40, 40, 50, 50, 55, 60, 60, 60, 70, 70, 80, 80, 90, 100, 105, 110, 120, 130, 135, 140, 145, 150, 170, 200};
	const int minget[30] = {10, 12, 15, 15, 20, 20, 25, 30, 35, 40, 40, 40, 45, 50, 60, 60, 60, 70, 80, 85 , 85 , 90 , 95 , 100, 100, 100, 100, 100, 100, 100};
	inline string to_stringf(double d){
		return to_string((int)d) + "." + to_string(((int)(d * 10)) % 10);
	}
	inline int ti(){
		return time(0);
	}
	inline void ex2(){
		clear();
		exit(0);
	}
	inline void ex(){
		clear();
		ex2();
	}
	int left_fish = 10000;
	bool auto_fishing = true;
	int left = 0;
	int ltime = 0;
	int money = 0;
}
namespace output{
	namespace auto_fishing{
		int runtime = 0;
		int time_now = 0;
		inline void draw_auto_fishing(){
			if(variate::left_fish == 0){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
				std::cout << std::endl;
				std::cout << std::endl;
				return;
			}
			if(runtime == 0){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 1){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "O                             |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime <= 19){
				string s;
				for(int i = 2; i < runtime; i++){
					s += ' ';
				}
				string s2;
				for(int i = runtime; i < 19; i++){
					s2 += ' ';
				}
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl;
				std::cout << s << ">O" << s2 << "           |       >O   |" << std::endl;
				std::cout << "                              |____________|" << std::endl;
			}else if(runtime == 20){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                 >O           |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 21){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~| O |~|       |~|   |~~~~~~|" << std::endl << "                  ^           |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 22){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                | O |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~| ^ |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 23){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                | O |           |   |" << std::endl << "                | ^ |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 24){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                | O .-----------.   |" << std::endl << "                | ^ |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 25){
				std::cout << "                .-------------------." << std::endl << "                | O                 |" << std::endl << "                | ^ .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime <= 41){
				string s, s2;
				for(int i = 26; i < runtime; i++){
					s += ' ';
				}
				for(int i = runtime; i < 41; i++){
					s2 += ' ';
				}
				std::cout << "                .-------------------." << std::endl << "                | ";
				std::cout << s << ">O" << s2;
				std::cout << " |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 42){
				std::cout << "                .-------------------." << std::endl << "                |                 v |" << std::endl << "                |   .-----------. O |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 43){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------. v |" << std::endl << "                |   |           | O |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 44){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           | v |" << std::endl << "                |   |  _______  | O |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 45){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  | v |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~| O |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 46){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~| v |~~~~~~|" << std::endl << "                              |   O        |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 47){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |   v        |" << std::endl << "                              |   O   >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 48){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |   >O  >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 49){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |    >O >O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 50){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |     >O>O   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 51){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |      >OO   |" << std::endl << "                              |____________|" << std::endl;
			}else if(runtime == 52){
				std::cout << "                .-------------------." << std::endl << "                |                   |" << std::endl << "                |   .-----------.   |" << std::endl << "                |   |           |   |" << std::endl << "                |   |  _______  |   |" << std::endl << "~~~~~~~~~~~~~~~~|   |~|       |~|   |~~~~~~|" << std::endl << "                              |            |" << std::endl << "                              |       >O   |" << std::endl << "                              |____________|" << std::endl;
			}
			std::cout << std::endl;
			std::cout << std::endl;
		}
		inline void check_fishing(){
			if(!variate::auto_fishing){
				return;
			}
			if(time_now < variate::ti()){
				time_now = variate::ti();
				runtime++;
				if(runtime > 52){
					runtime = 0;
					variate::left_fish--;
				}
			}else{
				return;
			}
			draw_auto_fishing();
			int now = time(0);
			variate::left += now - variate::ltime;
			variate::ltime = now;
			variate::money += variate::left / (variate::mintime[variate::level] + 20) * variate::maxget[variate::get_level];
			variate::left_fish += (variate::mintime[variate::level] + 20);
			variate::left %= (variate::mintime[variate::level] + 20);
		}
	}
	namespace screen{
		char c[143][13];
		int x1 = 0, y1 = 0;
		int x2 = 0, y2 = 0;
		inline void flush(){
			clear();
			for(int i = 0; i < 12; i++){
				for(int j = 0; j < 142; j++){
					std::cout << c[j][i];
				}
				std::cout << std::endl;
			}
			auto_fishing::check_fishing();
		}
		inline void print(string s){
			for(char i : s){
				if(x1 >= 141 || y1 >= 12){
					std::cout << "out of the screen";
					variate::ex2();
				}
				c[x1++][y1] = i;
			}
			flush();
		}
		inline void endl(){
			x1 = 0;
			y1++;
			if(y1 >= 12){
				std::cout << "out of the screen";
				variate::ex2();
			}
			flush();
		}
	}
	class endline{}endl;
	class output{
		public:
			output& operator<<(string a){
				screen::print(a);
				return *this;
			}
			output& operator<<(int a){
				*this << to_string(a);
				return *this;
			}
			output& operator<<(long long a){
				*this << to_string(a);
				return *this;
			}
			output& operator<<(double a){
				*this << variate::to_stringf(a);
				return *this;
			}
			inline void flush(){
				screen::flush();
			}
			output& operator<<(endline a){
				screen::endl();
				return *this;
			}
			// template<typename typname>output operator<<(typname b){
			//     std::cout << b << endl;
			//     return *this;
			// }
	}cout;
}
using output::cout;
using output::endl;
int main(){
	if(cols < 66 || line < 21){
		system("clear");
		std::cout << "终端至少需要21行66列" << std::endl;
		std::cout << "当前为" << line << "行" << cols << "列" << std::endl;
	}
	cout << "43wetrfaoewi" << endl << 1 << "ewfs" << 1.32 << 243232ll << endl;
}