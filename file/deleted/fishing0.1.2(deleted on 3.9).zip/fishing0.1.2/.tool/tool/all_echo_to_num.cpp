#include<iostream>
using namespace std;
int main(){
    system("stty raw");
    system("stty -echo");
    int cnt = 0;
    while(true){
        char c = getchar();
        cout << (int)c << '\r' << endl;
    }
}