#include<iostream>
using std::cin;
using std::cout;
#include"variate.h"
#include"color.h"
#include"base64.h"
#include"fishing.h"
#include"shop.h"
#include"checkpoint.h"
#include"tool.h"
#include"setting.h"
#include"function.h"
#include"story.h"
#include"first.h"
#include"error.h"
int main(){
	srand(time(0));
	clear();
	story();
	first::first();
	if(checkpoint::chp()){
		sleep(1);
		choose();
	}
	sleep(1);
	checkpoint::savechpnp(variate::name, false);
	while(true){
		clear();
		print("1.开始钓鱼, 2.进入商店, 3.存档, 4.读档, 5.设置自动保存, 6.开发者模式, 7.设置, 8.退出, 其他输入无效。");
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}
			if(type == '1'){
				error("fishing");
				clear();
				fishing::fishing_setup();
				break;
			}else if(type == '2'){
				clear();
				shop::shop();
				break;
			}else if(type == '3'){
				clear();
				checkpoint::save();
				break;
			}else if(type == '4'){
				clear();
				checkpoint::read();
				break;
			}else if(type == '5'){
				clear();
				checkpoint::set_auto_save();
				break;
			}else if(type == '6'){
				clear();
				tool::developer();
				break;
			}else if(type == '7'){
				clear();
				setting::setting();
				break;
			}else if(type == '8'){
				clear();
				return 0;
			}
		}
		checkpoint::auto_save();
		checkpoint::savechpnp(variate::name, false);
		sleep(0.5);
	}
}
