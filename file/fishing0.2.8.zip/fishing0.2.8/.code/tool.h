#ifndef tool_defined
#define tool_defined
#include<iostream>
#include<iomanip>
#include<vector>
using std::cout;
#include "variate.h"
#include "function.h"
#include "checkpoint.h"
namespace tool{
	inline void toolm(){
		if(variate::tool[2] != 2){
			clear();
			cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
			cout << "请输入密码: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 6719929333535458606){
				cout << "密码错误, 请重试: ";
				cout.flush();
				string mi;
				getline(mi);
				if(to_hash(mi) != 6719929333535458606){
					for(int i = 0; i < variate::tools; i++){
						variate::tool[i] = 0;
					}
					return;
				}
			}
		}
		variate::tool[2] = 2;
		clear();
		print("调试信息: ");
		print(checkpoint::de());
		print("\033[31;1mmain.开发者模式\033[m");
		print("1.金币数量, 2.关闭开发者模式, 3.封禁开发者模式, 按esc退出。");
		char c;
		while((c = getch()) != '1' && c != '2' && c != '3'){
			if(c == 27){
				return;
			}
		}
		if(c == '1'){
			int le = variate::money;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				if(le <= 10){
				}else if(le <= 100){
					le /= 10;
					le *= 10;
				}else if(le <= 1000){
					le /= 100;
					le *= 100;
				}else if(le <= 10000){
					le /= 1000;
					le *= 1000;
				}else if(le <= 100000){
					le /= 10000;
					le *= 10000;
				}else if(le <= 1000000){
					le /= 100000;
					le *= 100000;
				}else{
					le = 1000000;
				}
				cout << "金币数量:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "$" << (le < 1000000 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						if(le <= 10){
							le--;
						}else if(le <= 100){
							le -= 10;
						}else if(le <= 1000){
							le -= 100;
						}else if(le <= 10000){
							le -= 1000;
						}else if(le <= 100000){
							le -= 10000;
						}else if(le <= 1000000){
							le -= 100000;
						}
						break;
					}else if(c == 'd' && le < 1000000){
						if(le < 10){
							le++;
						}else if(le < 100){
							le += 10;
						}else if(le < 1000){
							le += 100;
						}else if(le < 10000){
							le += 1000;
						}else if(le < 100000){
							le += 10000;
						}else if(le < 1000000){
							le += 100000;
						}
						break;
					}else if(c == 13){
						variate::money = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '2'){
			for(int i = 0; i < variate::tools; i++){
				variate::tool[i] = 1;
			}
		}else if(c == '3'){
			for(int i = 0; i < variate::tools; i++){
				variate::tool[i] = 0;
			}
		}
	}
	inline void tool0(){
		if(variate::tool[0] == 1){
			clear();
			cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
			cout << "请输入密码: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 2281968572269345840ll){
				cout << "密码错误, 请重试: ";
				cout.flush();
				string mi;
				getline(mi);
				if(to_hash(mi) != 2281968572269345840ll){
					for(int i = 0; i < variate::tools; i++){
						variate::tool[i] = 0;
					}
					return;
				}
			}
			variate::tool[0] = 2;
		}
		clear();
		print("\033[31;1mshop0.开发者模式\033[m");
		print("1.上钩速度, 2.钓鱼收益, 3.脱钩概率, 4.清洁剂, 5.水族馆容量, 按esc退出。");
		char c;
		while((c = getch()) != '1' && c != '2' && c != '3' && c != '4' && c != '5'){
			if(c == 27){
				return;
			}
		}
		if(c == '1'){
			int le = variate::level;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "上钩速度:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < variate::max_level ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < variate::max_level){
						le++;
						break;
					}else if(c == 13){
						variate::level = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '2'){
			int le = variate::get_level;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "钓鱼收益:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < variate::max_level2 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < variate::max_level2){
						le++;
						break;
					}else if(c == 13){
						variate::get_level = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '3'){
			int le = variate::slip;
			while(true){
				clear();
				variate::slip /= 10;
				variate::slip *= 10;
				cout << "按a增加, 按d减少, 按enter保存, 按esc退出" << endl;
				cout << "脱钩概率:" << endl;
				cout << (le < 90 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << '%' << (le > 0 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le < 90){
						if(le >= 10){
							le += 10;
						}else if(le >= 5){
							le = 10;
						}else if(le >= 0){
							le += 1;
						}
						break;
					}else if(c == 'd' && le > 0){
						if(le > 10){
							le -= 10;
						}else if(le > 5){
							le = 5;
						}else if(le > 0){
							le -= 1;
						}
						break;
					}else if(c == 13){
						variate::slip = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '4'){
			int le = variate::cleaning_ball;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "清洁剂数量:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << (le < 1000 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						if(le <= 10){
							le--;
						}else if(le <= 100){
							le -= 10;
						}else{
							le -= 100;
						}
						break;
					}else if(c == 'd' && le < 1000){
						if(le < 10){
							le++;
						}else if(le < 100){
							le += 10;
						}else{
							le += 100;
						}
						break;
					}else if(c == 13){
						variate::cleaning_ball = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '5'){
			int le = variate::aqcnt;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "水族馆容量:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << (le < 50 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le--;
						break;
					}else if(c == 'd' && le < 50){
						le++;
						break;
					}else if(c == 13){
						variate::aqcnt = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}
	}
	inline void tool1(){
		if(variate::tool[1] == 1){
			clear();
			cout << "开发者模式, 如需使用此功能, 请询问开发者密码。" << endl;
			cout << "请输入密码: ";
			cout.flush();
			string mi;
			getline(mi);
			if(to_hash(mi) != 7777707626182367997ll){
				cout << "密码错误, 请重试: ";
				cout.flush();
				string mi;
				getline(mi);
				if(to_hash(mi) != 7777707626182367997ll){
					for(int i = 0; i < variate::tools; i++){
						variate::tool[i] = 0;
					}
					return;
				}
			}
			variate::tool[1] = 2;
		}
		clear();
		print("\033[31;1mshop1.开发者模式\033[m");
		print("1.甩杆倍速, 2.升级大鱼概率, 按esc退出。");
		char c;
		while((c = getch()) != '1' && c != '2'){
			if(c == 27){
				return;
			}
		}
		if(c == '1'){
			int le = variate::stime;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "甩杆倍速:" << endl;
				cout << (le > 1 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < 10 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 1){
						le--;
						break;
					}else if(c == 'd' && le < 10){
						le++;
						break;
					}else if(c == 13){
						variate::stime = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}else if(c == '2'){
			int le = variate::bf;
			while(true){
				clear();
				cout << "按a减少, 按d增加, 按enter保存, 按esc退出" << endl;
				cout << "大鱼概率:" << endl;
				cout << (le > 0 ? "\033[1m < \033[m" : "\033[0;31m < \033[m") << le << "级" << (le < 100 ? "\033[1m > \033[m" : "\033[0;31m > \033[m") << endl;
				while(true){
					char c = getch();
					if(c == 'a' && le > 0){
						le -= 5;
						break;
					}else if(c == 'd' && le < 100){
						le += 5;
						break;
					}else if(c == 13){
						variate::bf = le;
						return;
					}else if(c == 27){
						return;
					}
				}
			}
		}
	}
}
#endif