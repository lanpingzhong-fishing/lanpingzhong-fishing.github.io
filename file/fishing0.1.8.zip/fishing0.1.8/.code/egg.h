#ifndef egg_defined
#define egg_defined
#include<iostream>
#include<iomanip>
#include<vector>
using std::to_string;
using std::ostream;
using std::string;
using std::vector;
using std::pair;
using std::cout;
using std::setw;
using std::max;
#include"error.h"
#include"variate.h"
#include"function.h"
namespace egg{
	const int length = 6;
	bool have[length] = {};
	string name[length] = {"江湖骗子", "缺斤少两", "老赖", "鱼人节快乐", "传说中的鱼", "传说中的鸡蛋"};
	string type_name[3] = {"仅显示已获得成就", "仅显示未获得成绩", "全部显示"};
	int type = 2;
	inline void show(){
		print("");
		if(type == 2){
			print("全部成就:");
			for(int i = 0; i < length; i++){
				print("    " + name[i] + (have[i] ? ": 已获得" : ": 未获得"));
			}
		}else if(type == 0){
			print("已获得成就:");
			bool b = false;
			for(int i = 0; i < length; i++){
				if(have[i]){
					b = true;
					print("    " + name[i]);
				}
			}
			if(!b){
				print("    暂无");
			}
		}else if(type == 1){
			print("未获得成就:");
			bool b = false;
			for(int i = 0; i < length; i++){
				if(!have[i]){
					b = true;
					print("    " + name[i]);
				}
			}
			if(!b){
				print("    暂无");
			}
		}
	}
	inline void egg(){
		clear();
		print("1.切换显示模式, 2.退出");
		print("当前显示模式: " + type_name[type]);
		show();
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				type = (type + 1) % 3;
				print("1.切换显示模式, 2.退出");
				print("当前显示模式: " + type_name[type]);
				show();
			}else if(c == '2'){
				return;
			}
		}
	}
}
#endif