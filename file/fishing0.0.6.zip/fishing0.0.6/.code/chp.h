#ifndef chp_defined
#define chp_defined
#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<string>
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::ifstream;
using std::ofstream;
using std::to_string;
#include"base64.h"
#include"variate.h"
#include"function.h"
namespace checkpoint{
	bool auto_save_type = false;
	int timestamp = 0;
	string save_name;
	inline string de(){
		string s;
		s += "coin:";
		s += to_string(variate::money);
		s += "lv:";
		s += to_string(variate::level);
		s += "lv2:";
		s += to_string(variate::get_level);
		s += "c:";
		s += to_string(variate::cnt);
		s += "bf:";
		s += to_string(variate::bf);
		s += "st:";
		s += to_string(variate::stime);
		s += "af:";
		s += (variate::auto_fishing ? "t" : "f");
		s += "slip:";
		s += to_string(variate::slip);
		return s;
	}
	inline string encode(){
		string s = de();
		string gm1 = b1.encode(s);
		string gm2 = b2.encode(gm1);
		string gm3 = b3.encode(gm2);
		return gm3;
	}
	inline void decode(string gm3){
		string gm2, gm1, s, s_2, gm1_2, gm2_2, gm3_2;
		long long coin;
		int lv, lv2, c, bf, st, sl;
		char autofishing;
		if(b3.encode(gm2 = b3.decode(gm3)) != gm3){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询1" << endl;
			return;
		}
		if(b2.encode(gm1 = b2.decode(gm2)) != gm2){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		if(b1.encode(s = b1.decode(gm1)) != gm1){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		sscanf(s.c_str(), "coin:%lldlv:%dlv2:%dc:%dbf:%dst:%daf:%cslip:%d", &coin, &lv, &lv2, &c, &bf, &st, &autofishing, &sl);
		s_2 += "coin:";
		s_2 += to_string(coin);
		s_2 += "lv:";
		s_2 += to_string(lv);
		s_2 += "lv2:";
		s_2 += to_string(lv2);
		s_2 += "c:";
		s_2 += to_string(c);
		s_2 += "bf:";
		s_2 += to_string(bf);
		s_2 += "st:";
		s_2 += to_string(st);
		s_2 += "af:";
		s_2 += autofishing;
		s_2 += "slip:";
		s_2 += to_string(sl);
		if(s_2 != s){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询4" << endl;
			return;
		}
		if((gm1_2 = b1.encode(s_2)) != gm1){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询5" << endl;
			return;
		}
		if((gm2_2 = b2.encode(gm1_2)) != gm2){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询6" << endl;
			return;
		}
		if((gm3_2 = b3.encode(gm2_2)) != gm3){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询7" << endl;
			return;
		}
		variate::money = coin;
		variate::level = lv;
		variate::get_level = lv2;
		variate::cnt = c;
		variate::bf = bf;
		variate::stime = st;
		variate::auto_fishing = (autofishing == 't');
		variate::slip = sl;
		if(variate::auto_fishing){
			variate::ltime = time(0);
		}
		cout << "读取成功。" << endl;
	}
	inline void savechpnp(string name, bool b = true){
		ofstream out("checkpoint/" + name + ".checkpoint");
		out << encode() << endl;
		system(("echo \"" + name + "\" >> checkpoint/name.txt").c_str());
		system("sort -u -o checkpoint/name.txt checkpoint/name.txt");
		if(b){
			cout << "存档成功。" << endl;
		}
	}
	inline void savechp(string name){
		string ba, ba2;
		cout << "输入你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba);
		if(ba == "exit"){
			return;
		}
		cout << "确认你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba2);
		if(ba2 == "exit"){
			return;
		}
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		base64 base(ba, false);
		ofstream out("checkpoint/" + name + ".checkpoint");
		string gm4 = base.encode(encode());
		out << gm4 << endl;
		system(("echo \"" + name + "\" >> checkpoint/name.txt").c_str());
		system("sort -u -o checkpoint/name.txt checkpoint/name.txt");
		cout << "存档成功。" << endl;
	}
	inline void readchpnp(string name){
		string gm3;
		ifstream in("checkpoint/" + name + ".checkpoint");
		if(!in.good()){
			cout << "文件名错误, 具体文件可以去checkpoint/name.txt中查询" << endl;
			return;
		}
		in >> gm3;
		decode(gm3);
	}
	inline void readchp(string name){
		string gm4;
		ifstream in("checkpoint/" + name + ".checkpoint");
		if(!in.good()){
			cout << "文件名错误, 具体文件可以去checkpoint/name.txt中查询" << endl;
			return;
		}
		in >> gm4;
		string ba, ba2;
		cout << "输入你的读取密码: ";
		cout.flush();
		getline(ba);
		cout << "确认你的读取密码: ";
		cout.flush();
		getline(ba2);
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		clear();
		base64 base(ba, false);
		decode(base.decode(gm4));
	}
	inline void save(){
		print("1.无密码保存 2.带密码保存 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				savechpnp(name);
				break;
			}else if(type == '2'){
				savechp(name);
				break;
			}
		}
	}
	inline void read(){
		print("1.无密码读取 2.带密码读取 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "加载文件(只能有数字和大小写字母和下划线。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				readchpnp(name);
				break;
			}else if(type == '2'){
				readchp(name);
				break;
			}
		}
	}
	inline void check(){
		printa(de());
	}
	inline void auto_save(){
		if(auto_save_type){
			savechpnp(save_name + "_savetime_" + to_string(timestamp++), false);
		}
	}
	inline void set_auto_save(){
		string name;
		cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 最后文件将保存为\"名称_savetime_时间戳\", 例如\"c_savetime_3\", 输入\"exit\"即可退出: ";
		cout.flush();
		getline(name, true);
		if(name == "exit"){
			return;
		}
		bool b = true;
		for(char i : name){
			if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
				b = false;
				break;
			}
		}
		if(b){
			clear();
			auto_save_type = true;
			save_name = name;
			timestamp = 1;
			cout << "设置成功" << endl;
		}else{
			cout << "名称错误" << endl;
		}
	}
}
#endif