#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<ctime>
using std::cin;
using std::cout;
using std::ostream;
using std::string;
using std::to_string;
using std::ifstream;
using std::ofstream;
using std::hash;
using std::setw;
inline void clear(){
	system("clear");
}
struct endline{}endl;
inline ostream& operator<<(ostream& out, endline e){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
inline char getch(){
	char c = getchar();
	if(c == 3){
		clear();
		cout << "^C" << endl;
		system("stty cooked");
		system("stty echo");
		exit(0);
	}
//	if(c == 26){
//		clear();
//		cout << "^Z" << endl << "[1]+  Stopped                 fishing.run" << endl;
//		system("stty cooked");
//		system("stty echo");
//		exit(0);
//	}
	return c;
}
namespace variate{
	long long money = 20;
	int level = 0;
	const int max_level = 25;
	const int mintime[26] = {50, 40, 40, 40, 30, 30, 30, 30, 20, 20, 10, 9, 7, 5, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1};
	const int maxtime[26] = {100, 100, 90, 80, 80, 70, 60, 50, 50, 40, 40, 40, 40, 40, 40, 35, 30, 25, 20, 10, 5, 4, 4, 3, 3, 2};
	const int cost[26] = {0, 5, 5, 5, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 150, 200, 200, 200, 300, 350, 400, 500, 600, 700, 700};
	int get_level = 0;
	const int max_level2 = 29;
	const int maxget[30] = {20, 20, 20, 30, 30, 40, 40, 40, 50, 50, 55, 60, 60, 60, 70, 70, 80, 80, 90, 100, 105, 110, 120, 130, 135, 140, 145, 150, 170, 200};
	const int minget[30] = {10, 12, 15, 15, 20, 20, 25, 30, 35, 40, 40, 40, 45, 50, 60, 60, 60, 70, 80, 85 , 85 , 90 , 95 , 100, 100, 100, 100, 100, 100, 100};
	const int cost2[30] = {0, 20, 20, 20, 30, 40, 50, 60, 70, 80, 80, 80, 80, 90, 100, 150, 200, 200, 200, 300, 350, 400, 500, 600, 700, 700, 700, 700, 700, 700};
	int bf = 20;//20
	int cnt = 0;
	int stime = 1;//1
	string to_stringf(double d){
		return to_string((int)d) + "." + to_string(((int)(d * 10)) % 10);
	}
	long long ltime = 0, left = 0;
	bool auto_fishing = false;
	int spead = 2;//2
	int slip = 50;//50
}
bool issymbol(char type){
	string symbols = "({[<`~!@#$%^&*-_ +=|;:.?>]})\"'\\/";
	size_t found = symbols.find(type);
	if(found != string::npos){
		return true;
	}else{
		return false;
	}
}
inline string getline(string &ans, bool b = false){
	ans = "";
	char a = 0;
	while((a = getch()) != '\r'){
		if(issymbol(a) || isdigit(a) || islower(a) || isupper(a)){
			ans += a;
			if(b){
				cout << a;
				cout.flush();
			}
		}
		if(a == 127 && ans.length()){
			ans.pop_back();
			if(b){
				cout << "\b \b";
				cout.flush();
			}
		}
	}
	cout << endl;
	return ans;
}
inline unsigned long long to_hash(string s){
	return static_cast<unsigned long long>(hash<string>{}(s));
}
namespace color{
	string NONE = "\033[m";
	string RED = "\033[0;32;31m";
	string LIGHT_RED = "\033[1;31m";
	string GREEN = "\033[0;32;32m";
	string LIGHT_GREEN = "\033[1;32m";
	string BLUE = "\033[0;32;34m";
	string LIGHT_BLUE = "\033[1;34m";
	string DARY_GRAY = "\033[1;30m";
	string CYAN = "\033[0;36m";
	string LIGHT_CYAN = "\033[1;36m";
	string PURPLE = "\033[0;35m";
	string LIGHT_PURPLE = "\033[1;35m";
	string BROWN = "\033[0;33m";
	string YELLOW = "\033[1;33m";
	string LIGHT_GRAY = "\033[0;37m";
	string WHITE = "\033[1;37m";
	string SHINE = "\033[5m";       //闪烁
	string DASH = "\033[9m";        //中间一道横线
	string QUICKSHINE = "\033[6m";  //快闪
	string FANXIAN = "\033[7m";     //反显
	string XIAOYIN = "\033[8m";     //消隐, 消失隐藏
}
inline void sleep(double time){
	system(((string)"sleep " + to_string(time)).c_str());
}
inline void print(string s, double time = 0.02){
	if(variate::spead == 1000){
		cout << s << endl;
	}else{
		for(char i : s){
			sleep(time / variate::spead);
			cout << i;
			cout.flush();
		}
		cout << endl;
	}
}
inline void printa(string s, double time = 0.02){
	print(s + "    (按enter继续)", time);
	while(getch() != '\r');
}
namespace get_random{
	inline int random(int l, int r){
		int len = r - l;
		int re = rand() * 1.0 / RAND_MAX * len + l;
		return re;
	}
	inline int level_rand(int l = variate::level){
		return random(variate::mintime[l], variate::maxtime[l]);
	}
	inline int gr(int l = variate::get_level){
		return random(variate::minget[l], variate::maxget[l]);
	}
	inline int gbr(int l = variate::get_level){
		return random(variate::minget[l] * 2, variate::maxget[l] * 2);
	}
	inline int get_rand(bool is_big){
		return (is_big ? gbr() : gr());
	}
	inline int getgiant_rand(){
		return random(9000, 10000);
	}
	inline void get(bool is_big){
		int pri = get_rand(is_big);
		variate::money += pri;
		printa((string)"你钓到了一条" + (is_big ? "大" : "") + "鱼, 价值$" + to_string(pri) + ", 你现在有$" + to_string(variate::money));
	}
	inline void getgiant(){
		int pri = getgiant_rand();
		variate::money += pri;
		printa((string)"你钓到了一条巨型鲨鱼, 价值$" + to_string(pri) + ", 你现在有$" + to_string(variate::money));
	}
}
class base64{
	private:
		int basedecode[128];
		char baseencode[65];
		char oth;
		bool use[7];
		int ans[7];
		int tot;
		char tb(int n){
			return baseencode[n & 0x3f];
		}
		void quan(int n, int b){
			if(n >= 6){
				tot++;
				return;
			}
			for(int i = 0; i <= 4; i++){
				if(use[i]){
					continue;
				}
				use[i] = true;
				ans[n] = i;
				quan(n + 1, b);
				use[i] = false;
				if(b == tot){
					return;
				}
			}
		}
		string get_password(string s){
			size_t ha = hash<string>{}(s);
			unsigned long long  num = static_cast<unsigned long long>(ha);
			char a[6] = "aA1";
			string list = "({[<`~!@#$%^&*-_+=|;:.?>]})";
			unsigned long long n1 = num / list.length();
			unsigned long long r1 = num % list.length();
			unsigned long long n2 = n1 / (list.length() - 1);
			unsigned long long r2 = n1 % (list.length() - 1);
			unsigned long long n3 = n2 / (list.length() - 2);
			unsigned long long r3 = n2 % (list.length() - 2);
			unsigned long long n4 = n3 / 120;
			unsigned long long r4 = n3 % 120;
			a[3] = list[r1];
			list.erase(r1, 1);
			a[4] = list[r2];
			list.erase(r2, 1);
			a[5] = list[r3];
			for(int i = 0; i <= 4; i++){
				use[i] = false;
				ans[i] = 0;
			}
			ans[6] = 5;
			quan(1, r4 + 1);
			string an;
			for(int i = 1; i <= 6; i++){
				an += a[ans[i]];
			}
			return an;
		}
		void set_base(string s){
			int i = 0;
			for(int i = 0; i < 64; i++){
				baseencode[i] = '\0';
			}
			for(int i = 0; i < 128; i++){
				basedecode[i] = '\0';
			}
			oth = s[5];
			for(int j = 0; j < 5; j++){
				if(isdigit(s[j])){
					for(int j = 0; j < 10; j++){
						basedecode[j + '0'] = i;
						baseencode[i++] = j + '0';
					}
				}else if(islower(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'a'] = i;
						baseencode[i++] = j + 'a';
					}
				}else if(isupper(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'A'] = i;
						baseencode[i++] = j + 'A';
					}
				}else{
					basedecode[s[j]] = i;
					baseencode[i++] = s[j];
				}
			}
		}
	public:
		base64(string s){
			set_base(s);
		}
		base64(string s, bool salt){
			if(salt){
				set_base(get_password(s + "add_salt"));
			}else{
				set_base(get_password(s + "no_salt"));
			}
		}
		string decode(string in){//jiema
			string ans;
			for(int i = 0; i < in.length(); i += 4){
				ans += (char)((unsigned char)basedecode[in[i]] << 2 | (unsigned char)basedecode[in[i + 1]] >> 4) & 0xff;
				if(in[i + 2] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 1]] << 4 | (unsigned char)basedecode[in[i + 2]] >> 2) & 0xff;
				}
				if(in[i + 3] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 2]] << 6 | (unsigned char)basedecode[in[i + 3]]) & 0xff;
				}
			}
			return ans;
		}
		string encode(string in){//bianma
			string ans;
			for(int i = 0; i < in.length(); i += 3){
				ans += tb(((unsigned char)in[i] >> 2));
				ans += tb(((unsigned char)in[i] << 4) | (i + 1 >= in.length() ? 0 : ((unsigned char)in[i + 1] >> 4)));
				ans += (i + 1 >= in.length()) ? oth : tb(((unsigned char)in[i + 1] << 2) | (i + 2 >= in.length() ? 0 : ((unsigned char)in[i + 2] >> 6)));
				ans += (i + 2 >= in.length()) ? oth : tb(((unsigned char)in[i + 2]));
			}
			while(ans.length() % 4){
				ans += oth;
			}
			return ans;
		}
}b1("a[0]A`"), b2("(0aA);"), b3("|a0+A-");
namespace fishing{
	inline void fishing0(bool is_big){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		int stime = get_random::level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;33mO\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << ">\033[1;33mO\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m>\033[1;33mO\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  \033[1;33mO\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m^\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  \033[1;33mO\33[m     V|\\" << endl << "                  ^     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  \033[1;33mO\33[m    \\ o" << endl << "                  ^     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  \033[1;33mO\33[m   \\" << endl << "                  ^    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  \033[1;33mO\33[m  \\" << endl << "                  ^   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  \033[1;33mO\33[m \\" << endl << "                  ^  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  \033[1;33mO\33[m\\" << endl << "                  ^ \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       >\033[1;33mO\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       >\033[1;33mO\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                         >\033[1;33mO\33[m" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                              >\033[1;33mO\33[m" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o         v" << endl << "                        /|\\--------\033[1;33mO\33[m" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------v" << endl << "                        /_\\___     \033[1;33mO\33[m" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___     V " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~\033[m\033[1;33mO\33[m\033[1;34m~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~\\\033[mv\033[1;34m/~~~~~~\033[m|" << endl << "                              |    \033[1;33mO\33[m       |" << endl << "                              |            |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |    v       |" << endl << "                              |    \033[1;33mO\33[m       |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |    >\033[1;33mO\33[m      |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |     >\033[1;33mO\33[m     |" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx1  |" << endl << "                              |____________|" << endl;
		variate::cnt = 1;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		get_random::get(is_big);
	}
	inline void fishing1(bool is_big){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		int stime = get_random::level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;33mO\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << ">\033[1;33mO\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m>\033[1;33mO\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  \033[1;33mO\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m^\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  \033[1;33mO\33[m     V|\\" << endl << "                  ^     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  \033[1;33mO\33[m    \\ o" << endl << "                  ^     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  \033[1;33mO\33[m   \\" << endl << "                  ^    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  \033[1;33mO\33[m  \\" << endl << "                  ^   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  \033[1;33mO\33[m \\" << endl << "                  ^  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  \033[1;33mO\33[m\\" << endl << "                  ^ \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       >\033[1;33mO\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                       >\033[1;33mO\33[m" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                         >\033[1;33mO\33[m" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                              >\033[1;33mO\33[m" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o         v" << endl << "                        /|\\--------\033[1;33mO\33[m" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------v" << endl << "                        /_\\___     \033[1;33mO\33[m" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___     V " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~\033[m\033[1;33mO\33[m\033[1;34m~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~\\\033[mv\033[1;34m/~~~~~~\033[m|" << endl << "                              |    \033[1;33mO\33[m       |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |    v       |" << endl << "                              |    \033[1;33mO\33[m >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |    >\033[1;33mO\33[m>\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |     >\033[1;33mO\33[m\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___ " << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(++variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		get_random::get(is_big);
	}
	inline void fishing1die(bool is_big){
		clear();
		cout << endl << endl << endl << endl << endl << "                         o" << endl << "                        /|\\--------" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                               /" << endl << "                              /" << endl << "                             /" << endl << "                            /" << endl << "                         o /" << endl << "                        /|v" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                          |" << endl << "                         o|" << endl << "                        /||" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |" << endl << "                        |o" << endl << "                        ||\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  j\\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  j \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  j  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  j   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  j    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  j     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  j     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		int stime = get_random::level_rand();
		sleep(stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;33mO\33[m\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		for(int i = 1; i <= 17; i++){
			clear();
			cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl;
			for(int j = 1; j < i; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << ">\033[1;33mO\33[m";
			for(int j = i; j <= 16; j++){
				cout << "\033[1;34m~\033[m";
			}
			cout << "j\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
			sleep(0.5 * (is_big + 1) / variate::stime);
		}
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\033[m>\033[1;33mO\33[m\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  \033[1;33mO\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[m^\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  \033[1;33mO\33[m     V|\\" << endl << "                 ^      /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  \033[1;33mO\33[m    \\ o" << endl << "                   ^    V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  \033[1;33mO\33[m   \\" << endl << "                 ^     \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  | \\" << endl << "                  \033[1;33mO\33[m  \\" << endl << "                   ^  \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                  \033[1;33mO\33[m \\" << endl << "                 ^   \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                  |\\" << endl << "                    \\" << endl << "                 >\033[1;33mO\33[m  \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                  v  \\" << endl << "                  \033[1;33mO\33[m   \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                  v   \\" << endl << "                  \033[1;33mO\33[m    \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                  v    \\ o" << endl << "                  \033[1;33mO\33[m     V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                  v     V|\\" << endl << "                  \033[1;33mO\33[m     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                  v     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\\\033[m\033[1;33mO\33[m\033[1;34m/~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~\\\033[mv\033[1;34m/~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                  \033[1;33mO\33[m           |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                 \033[1;33mO\33[m<           |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                 v            |            |" << endl << "                 \033[1;33mO\33[m            |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                 v            |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                 \033[1;33mO\33[m            |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                 v            |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
		sleep(0.3 / (is_big + 1) / variate::stime);
		clear();
		cout << endl << "                   \\" << endl << "                    \\" << endl << "                     \\" << endl << "                      \\" << endl << "                       \\ o" << endl << "                        V|\\" << endl << "                        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[m" << setw(4) << ("x" + to_string(variate::cnt))  << "|" << endl << "                              |____________|" << endl;
	}
	inline void fishing2(){
		clear();
		printa("巨型鲨鱼即将出现");
		clear();
		cout << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(get_random::random(2,5));
		clear();
		cout << "                  |\\" << endl << "                  | \\" << endl << "                  |  \\" << endl << "                  |   \\" << endl << "                  |    \\ o" << endl << "                  |     V|\\" << endl << "                  |     /_\\___" << endl << "\\\033[1;34m~~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  |   \\            |_|" << endl << "                  |    \\ o          _" << endl << "                  |     V|\\        (_)" << endl << "\\                 |     /_\\___" << endl << " \\\033[1;34m~~~~~~~~~~~~~~~~\033[mj\033[1;34m~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  |   \\            |_|" << endl << "                  |    \\ o          _" << endl << "\\                 j     V|\\        (_)" << endl << " \\                      /_\\___" << endl << "  \\\033[1;34m~~~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  | \\              | |" << endl << "                  |  \\             | |" << endl << "                  j   \\            |_|" << endl << "                       \\ o          _" << endl << " |\\                     V|\\        (_)" << endl << " | \\                    /_\\___" << endl << "\033[1;34m~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                  |\\                _" << endl << "                  j \\              | |" << endl << "                     \\             | |" << endl << "                      \\            |_|" << endl << "                       \\ o          _" << endl << "  |\\                    V|\\        (_)" << endl << "  | \\                   /_\\___" << endl << "\033[1;34m~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                   \\                _" << endl << "                    \\              | |" << endl << "                     \\             | |" << endl << "                      \\            |_|" << endl << "                       \\ o          _" << endl << "   |\\                   V|\\        (_)" << endl << "   | \\                  /_\\___" << endl << "\033[1;34m~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                        |           _" << endl << "                        |          | |" << endl << "                        |          | |" << endl << "                        |          |_|" << endl << "                        |o          _" << endl << "    |\\                  ||\\        (_)" << endl << "    | \\                 /_\\___" << endl << "\033[1;34m~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "     |\\                 /||        (_)" << endl << "     | \\                /_\\___" << endl << "\033[1;34m~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "      |\\                /||        (_)" << endl << "      | \\               /_\\___" << endl << "\033[1;34m~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "       |\\               /||        (_)" << endl << "       | \\              /_\\___" << endl << "\033[1;34m~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "        |\\              /||        (_)" << endl << "        | \\             /_\\___" << endl << "\033[1;34m~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "         |\\             /||        (_)" << endl << "         | \\            /_\\___" << endl << "\033[1;34m~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "          |\\            /||        (_)" << endl << "          | \\           /_\\___" << endl << "\033[1;34m~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "           |\\           /||        (_)" << endl << "           | \\          /_\\___" << endl << "\033[1;34m~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "            |\\          /||        (_)" << endl << "            | \\         /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "             |\\         /||        (_)" << endl << "             | \\        /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                          |         _" << endl << "                          |        | |" << endl << "                          |        | |" << endl << "                          |        |_|" << endl << "                         o|         _" << endl << "              |\\        /||        (_)" << endl << "              | \\       /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		cout << "                /         |         _" << endl << "               /          |        | |" << endl << "              /____       |        | |" << endl << "                  /       |        |_|" << endl << "                 /       o|         _" << endl << "              |\\/       /||        (_)" << endl << "              | \\       /_\\___" << endl << "\033[1;34m~~~~~~~~~~~~~~\033[m|  \\\033[1;34m~~~~~\033[m|      |\033[1;34m~~~~~~~~~~~~\033[m|" << endl << "                              |            |" << endl << "                              |      >\033[1;33mO\33[mx99 |" << endl << "                              |____________|" << endl;
		sleep(0.5 / variate::stime);
		clear();
		get_random::getgiant();
	}
	inline void fishing(){
		bool b = (get_random::random(1, 100) <= variate::bf);
		if(variate::cnt && variate::cnt < 99){
			bool die = (get_random::random(1, 100) <= variate::slip);
			if(die){
				fishing1die(b);
			}else{
				fishing1(b);
			}
		}else if(variate::cnt >= 99){
			fishing2();
			variate::cnt = 0;
		}else{
			fishing0(b);
		}
	}
}
namespace shop{
	inline void check_fishing(){
		if(!variate::auto_fishing){
			return;
		}
		int now = time(0);
		variate::left += now - variate::ltime;
		variate::ltime = now;
		variate::money += variate::left / (variate::mintime[variate::level] + 20) * variate::maxget[variate::get_level];
		variate::cnt += variate::left / (variate::mintime[variate::level] + 20);
		variate::left %= (variate::mintime[variate::level] + 20);
	}
	inline void shop0(){
		clear();
		print("1.升级上钩速度, 2.升级钓鱼收益, 3.脱钩概率, 4.返回。");
		print("只用输入编号", 0.01);
		print("上钩速度: ");
		if(variate::level == variate::max_level){
			print("    等级已满。");
		}else{
			print("    当前平均时间: " + to_string((variate::mintime[variate::level] + variate::maxtime[variate::level]) >> 1) + (((variate::mintime[variate::level] + variate::maxtime[variate::level]) & 1) ? ".5" : "") + ", 升级后平均时间: " + to_string((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) >> 1) + (((variate::mintime[variate::level + 1] + variate::maxtime[variate::level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost[variate::level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("钓鱼收益: ");
		if(variate::get_level == variate::max_level2){
			print("    等级已满。");
		}else{
			print("    当前平均收益: " + to_string((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) >> 1) + (((variate::minget[variate::get_level] + variate::maxget[variate::get_level]) & 1) ? ".5" : "") + ", 升级后平均收益: " + to_string((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) >> 1) + (((variate::minget[variate::get_level + 1] + variate::maxget[variate::get_level + 1]) & 1) ? ".5" : ""));
			print("    升级花费: $" + to_string(variate::cost2[variate::get_level + 1]) + ", 当前金币数量: $" + to_string(variate::money));
		}
		print("脱钩概率: ");
		if(variate::slip == 0){
			print("    等级已满。");
		}else{
			if(variate::slip > 10){
				variate::slip /= 10;
				variate::slip *= 10;
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 10) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 5){
				variate::slip = 10;
				print("    当前脱钩概率: 10%, 升级后脱钩概率: 5%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else if(variate::slip > 1){
				print("    当前脱钩概率: " + to_string(variate::slip) + "%, 升级后脱钩概率: " + to_string(variate::slip - 1) + "%");
				print("    升级花费: $100, 当前金币数量: $" + to_string(variate::money));
			}else{
				print("    当前脱钩概率: 1%, 升级后脱钩概率: 0%");
				print("    升级花费: $500, 当前金币数量: $" + to_string(variate::money));
			}
		}
		char type = 0;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::level == variate::max_level){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost[variate::level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost[++variate::level];
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::get_level == variate::max_level2){
					print("等级已满");
					break;
				}else if(variate::money < variate::cost2[variate::get_level + 1]){
					print("金钱不够");
					break;
				}else{
					variate::money -= variate::cost2[++variate::get_level];
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				if(variate::slip == 0){
					print("等级已满");
					break;
				}else if(variate::slip == 1){
					if(variate::money < 500){
						print("金钱不够");
						break;
					}else{
						variate::money -= 500;
						variate::slip = 0;
						print("购买成功");
						break;
					}
				}else{
					if(variate::money < 100){
						print("金钱不够");
						break;
					}else{
						variate::money -= 100;
						if(variate::slip > 10){
							variate::slip -= 10;
						}else if(variate::slip > 5){
							variate::slip = 5;
						}else if(variate::slip > 0){
							variate::slip -= 1;
						}
						print("购买成功");
						break;
					}
				}
			}else if(type == '4'){
				break;
			}
		}
	}
	inline void shop1(){
		clear();
		printa("这里是超级商店, 可以买一些特殊的商品。");
		clear();
		print("1.游戏倍速, 2.升级大鱼概率 3.购买自动钓鱼机, 4.返回。");
		print("只用输入编号", 0.01);
		print("游戏倍速: ");
		if(variate::stime == 0.1){
			print("    等级已满。");
		}else{
			print("    当前倍速: " + to_string(variate::stime) + ", 升级后游戏倍速: " + to_string(variate::stime + 1));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		print("大鱼概率: ");
		if(variate::bf >= 60){
			print("    等级已满。");
		}else{
			print("    当前大鱼概率: " + to_string(variate::bf) + ", 升级后大鱼概率" + to_string(variate::bf + 5));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		print("自动钓鱼机: ");
		if(variate::auto_fishing){
			print("    已有");
		}else{
			print("    升级花费: $2000, 当前金币数量: $" + to_string(variate::money));
		}
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::stime >= 10){
					print("等级已满。");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::stime++;
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::bf >= 60){
					print("等级已满。");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::bf += 5;
					print("购买成功");
					break;
				}
			}else if(type == '3'){
				if(variate::auto_fishing){
					print("等级已满。");
					break;
				}else if(variate::money < 2000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 2000;
					variate::auto_fishing = true;
					variate::ltime = time(0);
					print("购买成功");
					break;
				}
				break;
			}else if(type == '4'){
				break;
			}
		}
	}
	inline void shop(){
		clear();
		if(variate::level != variate::max_level || variate::get_level != variate::max_level2){
			print("1.普通商店, 2.超级商店, 3.退出。");
			char type;
			while(true){
				type = getch();
				if(type == '1'){
					shop0();
					break;
				}else if(type == '2'){
					shop1();
					break;
				}else if(type == '3'){
					break;
				}
			}
		}else{
			shop1();
		}
	}
}
namespace checkpoint{
	bool auto_save_type = false;
	int timestamp = 0;
	string save_name;
	inline string de(){
		string s;
		s += "coin:";
		s += to_string(variate::money);
		s += "lv:";
		s += to_string(variate::level);
		s += "lv2:";
		s += to_string(variate::get_level);
		s += "c:";
		s += to_string(variate::cnt);
		s += "bf:";
		s += to_string(variate::bf);
		s += "st:";
		s += to_string(variate::stime);
		s += "af:";
		s += (variate::auto_fishing ? "t" : "f");
		s += "slip:";
		s += to_string(variate::slip);
		return s;
	}
	inline string encode(){
		string s = de();
		string gm1 = b1.encode(s);
		string gm2 = b2.encode(gm1);
		string gm3 = b3.encode(gm2);
		return gm3;
	}
	inline void decode(string gm3){
		string gm2, gm1, s, s_2, gm1_2, gm2_2, gm3_2;
		long long coin;
		int lv, lv2, c, bf, st, sl;
		char autofishing;
		if(b3.encode(gm2 = b3.decode(gm3)) != gm3){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询1" << endl;
			return;
		}
		if(b2.encode(gm1 = b2.decode(gm2)) != gm2){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		if(b1.encode(s = b1.decode(gm1)) != gm1){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		sscanf(s.c_str(), "coin:%lldlv:%dlv2:%dc:%dbf:%dst:%daf:%cslip:%d", &coin, &lv, &lv2, &c, &bf, &st, &autofishing, &sl);
		s_2 += "coin:";
		s_2 += to_string(coin);
		s_2 += "lv:";
		s_2 += to_string(lv);
		s_2 += "lv2:";
		s_2 += to_string(lv2);
		s_2 += "c:";
		s_2 += to_string(c);
		s_2 += "bf:";
		s_2 += to_string(bf);
		s_2 += "st:";
		s_2 += to_string(st);
		s_2 += "af:";
		s_2 += autofishing;
		s_2 += "slip:";
		s_2 += to_string(sl);
		if(s_2 != s){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询4" << endl;
			return;
		}
		if((gm1_2 = b1.encode(s_2)) != gm1){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询5" << endl;
			return;
		}
		if((gm2_2 = b2.encode(gm1_2)) != gm2){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询6" << endl;
			return;
		}
		if((gm3_2 = b3.encode(gm2_2)) != gm3){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询7" << endl;
			return;
		}
		variate::money = coin;
		variate::level = lv;
		variate::get_level = lv2;
		variate::cnt = c;
		variate::bf = bf;
		variate::stime = st;
		variate::auto_fishing = (autofishing == 't');
		variate::slip = sl;
		if(variate::auto_fishing){
			variate::ltime = time(0);
		}
		cout << "读取成功。" << endl;
	}
	inline void savechpnp(string name, bool b = true){
		ofstream out("checkpoint/" + name + ".checkpoint");
		out << encode() << endl;
		system(("echo \"" + name + "\" >> checkpoint/name.txt").c_str());
		system("sort -u -o checkpoint/name.txt checkpoint/name.txt");
		if(b){
			cout << "存档成功。" << endl;
		}
	}
	inline void savechp(string name){
		string ba, ba2;
		cout << "输入你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba);
		if(ba == "exit"){
			return;
		}
		cout << "确认你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba2);
		if(ba2 == "exit"){
			return;
		}
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		base64 base(ba, false);
		ofstream out("checkpoint/" + name + ".checkpoint");
		string gm4 = base.encode(encode());
		out << gm4 << endl;
		system(("echo \"" + name + "\" >> checkpoint/name.txt").c_str());
		system("sort -u -o checkpoint/name.txt checkpoint/name.txt");
		cout << "存档成功。" << endl;
	}
	inline void readchpnp(string name){
		string gm3;
		ifstream in("checkpoint/" + name + ".checkpoint");
		if(!in.good()){
			cout << "文件名错误, 具体文件可以去checkpoint/name.txt中查询" << endl;
			return;
		}
		in >> gm3;
		decode(gm3);
	}
	inline void readchp(string name){
		string gm4;
		ifstream in("checkpoint/" + name + ".checkpoint");
		if(!in.good()){
			cout << "文件名错误, 具体文件可以去checkpoint/name.txt中查询" << endl;
			return;
		}
		in >> gm4;
		string ba, ba2;
		cout << "输入你的读取密码: ";
		cout.flush();
		getline(ba);
		cout << "确认你的读取密码: ";
		cout.flush();
		getline(ba2);
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		clear();
		base64 base(ba, false);
		decode(base.decode(gm4));
	}
	inline void save(){
		print("1.无密码保存 2.带密码保存 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				savechpnp(name);
				break;
			}else if(type == '2'){
				savechp(name);
				break;
			}
		}
	}
	inline void read(){
		print("1.无密码读取 2.带密码读取 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "加载文件(只能有数字和大小写字母和下划线。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				readchpnp(name);
				break;
			}else if(type == '2'){
				readchp(name);
				break;
			}
		}
	}
	inline void check(){
		printa(de());
	}
	inline void auto_save(){
		if(auto_save_type){
			savechpnp(save_name + "_savetime_" + to_string(timestamp++), false);
		}
	}
	inline void set_auto_save(){
		string name;
		cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 最后文件将保存为\"名称_savetime_时间戳\", 例如\"c_savetime_3\", 输入\"exit\"即可退出: ";
		cout.flush();
		getline(name, true);
		if(name == "exit"){
			return;
		}
		bool b = true;
		for(char i : name){
			if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
				b = false;
				break;
			}
		}
		if(b){
			clear();
			auto_save_type = true;
			save_name = name;
			timestamp = 1;
			cout << "设置成功" << endl;
		}else{
			cout << "名称错误" << endl;
		}
	}
}
namespace tool{
	void ch(){
		clear();
		cout << "int money = " << variate::money << "; (金钱, 最大100000)" << endl << 
		"int level = " << variate::level << "; (上钩速度, 最小0, 最大25)" << endl << 
		"int get_level = " << variate::get_level << "; (钓鱼收益, 最小0, 最大29)" << endl << 
		"int bf = " << variate::bf << "; (大鱼概率, 最小20, 最大60)" << endl << 
		"double stime = " << variate::stime << "; (游戏倍速, 最大10, 最小1)" << endl <<
		"int cnt = " << variate::cnt << "; (总钓鱼数量, 最小0, 最大1000000)" << endl;
		print("1.修改money, 2.修改lever, 3.修改get_lever, 4.修改bf, 5.修改stime, 6.修改cnt, 7.自动钓鱼机, 8.自动调整, 9.退出");
		while(true){
			char c = getch();
			if(c != '1' && c != '2' && c != '3' && c != '4' && c != '5' && c != '6' && c != '7' && c != '8' && c != '9'){
				continue;
			}
			if(c != '7' && c != '8' && c != '9'){
				cout << c << ".0";
				cout.flush();
			}
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 100000){
							s = 100000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::money = s;
			}else if(c == '2'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 25){
							s = 25;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::level = s;
			}else if(c == '3'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 29){
							s = 29;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::get_level = s;
			}else if(c == '4'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 60){
							s = 60;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::bf = s;
			}else if(c == '5'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 10){
							s = 10;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::stime = s;
			}else if(c == '6'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000000){
							s = 1000000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::cnt = s;
			}else if(c == '7'){
				variate::auto_fishing = true;
			}else if(c == '8'){
				variate::money = 100000;
				variate::level = 25;
				variate::get_level = 29;
				variate::bf = 60;
				variate::stime = 10;
				variate::cnt = 100;
				variate::auto_fishing = true;
				variate::slip = 10;
			}
			break;
		}
	}
	void hack(){
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.修改状态, 3.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				ch();
				return;
			}else if(c == '3'){
				clear();
				return;
			}
		}
	}
	void lower_hack(){
		clear();
		cout << "  ______     ____      ____     _____" << endl << " |  ____|   / __ \\    / __ \\   |  __ \\" << endl << " | | ___   | |  | |  | |  | |  | |  | |" << endl << " | ||_  |  | |  | |  | |  | |  | |  | |" << endl << " | |__| |  | |__| |  | |__| |  | |__| | " << endl << " |______|   \\____/    \\____/   |_____/ " << endl << "                                        " << endl << "                                        " << endl;
		print("GOOD JOB");
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				clear();
				return;
			}
		}
	}
	void developer(){
		clear();
		string mi;
		print("欢迎来到开发者模式");
		cout << "请输入密码: ";
		cout.flush();
		getline(mi);
		if(to_hash(mi) == 12386266893725306769ull){
			hack();
		}else{
			lower_hack();
		}
	}
}
namespace setting{
	void setting(){
		print("1.更改输出倍速, 2.退出");
		print("当前输出倍速: " + to_string(variate::spead) + "(最大1000)");
		while(true){
			char c = getch();
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000){
							s = 1000;
						}
						cout << "\r          \r" << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::spead = s;
				return;
			}else if(c == '2'){
				return;
			}
		}
	}
}
int main(){
	srand(time(0));
	system("stty raw");
	system("stty -echo");
	clear();
	printa("欢迎来到自助钓鱼系统。");
	printa("你可以在这里钓鱼。");
	printa("升级装备可以让钓鱼效率更高。");
	while(true){
		clear();
		print("1.开始钓鱼, 2.进入商店, 3.存档, 4.读档, 5.设置自动保存, 6.开发者模式, 7.设置, 8.退出, 其他输入无效。");
		print("只用输入编号", 0.01);
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}
			if(type == '1'){
				clear();
				fishing::fishing();
				sleep(0.5);
				break;
			}else if(type == '2'){
				clear();
				shop::shop();
				break;
			}else if(type == '3'){
				clear();
				checkpoint::save();
				break;
			}else if(type == '4'){
				clear();
				checkpoint::read();
				break;
			}else if(type == '5'){
				clear();
				checkpoint::set_auto_save();
				break;
			}else if(type == '6'){
				clear();
				tool::developer();
				break;
			}else if(type == '7'){
				clear();
				setting::setting();
				break;
			}else if(type == '8'){
				clear();
				system("stty cooked");
				system("stty echo");
				return 0;
			}
		}
		checkpoint::savechpnp("last", false);
		shop::check_fishing();
		checkpoint::auto_save();
		sleep(1);
	}
}
