#ifndef tool_defined
#define tool_defined
#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<string>
using std::cout;
using std::hash;
using std::string;
using std::ostream;
using std::ifstream;
using std::ofstream;
using std::to_string;
#include"base64.h"
#include"variate.h"
#include"function.h"
#include"checkpoint.h"
namespace tool{
	void ch(){
		clear();
		cout << "int money = " << variate::money << "; (金钱, 最大100000)" << endl << 
		"int level = " << variate::level << "; (上钩速度, 最小0, 最大25)" << endl << 
		"int get_level = " << variate::get_level << "; (钓鱼收益, 最小0, 最大29)" << endl << 
		"int bf = " << variate::bf << "; (大鱼概率, 最小20, 最大60)" << endl << 
		"int stime = " << variate::stime << "; (游戏倍速, 最大10, 最小1)" << endl <<
		"int cnt = " << variate::cnt << "; (总钓鱼数量, 最小0, 最大1000000)" << endl <<
		"int slip = " << variate::slip << "; (脱钩概率, 最小0, 最大50)" << endl <<
		"int clean = " << variate::cleaning_ball << "; (清洁剂, 最小0, 最大1000)" << endl;
		print("1.修改money, 2.修改lever, 3.修改get_lever, 4.修改bf, 5.修改stime, 6.修改cnt, 7.自动钓鱼机, 8.脱钩概率, 9.清洁剂, a.自动调整, b.退出");
		while(true){
			char c = getch();
			if(c != '1' && c != '2' && c != '3' && c != '4' && c != '5' && c != '6' && c != '7' && c != '8' && c != '9' && c != 'a' && c != 'b'){
				continue;
			}
			if(c != '7' && c != '8' && c != '9'){
				cout << c << ".0";
				cout.flush();
			}
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 100000){
							s = 100000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::money = s;
			}else if(c == '2'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 25){
							s = 25;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::level = s;
			}else if(c == '3'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 29){
							s = 29;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::get_level = s;
			}else if(c == '4'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 60){
							s = 60;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::bf = s;
			}else if(c == '5'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 10){
							s = 10;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::stime = s;
			}else if(c == '6'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000000){
							s = 1000000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::cnt = s;
			}else if(c == '7'){
				variate::auto_fishing = true;
			}else if(c == '8'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 50){
							s = 50;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::slip  = s;
			}else if(c == '9'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000){
							s = 1000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::cleaning_ball = s;
			}else if(c == 'a'){
				variate::money = 100000;
				variate::level = 25;
				variate::get_level = 29;
				variate::bf = 60;
				variate::stime = 10;
				variate::cnt = 100;
				variate::auto_fishing = true;
				variate::slip = 0;
				variate::cleaning_ball = 1000;
			}
			break;
		}
	}
	void hack(){
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.修改状态, 3.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				ch();
				return;
			}else if(c == '3'){
				clear();
				return;
			}
		}
	}
	void lower_hack(){
		clear();
		cout << "  ______     ____      ____     _____" << endl << " |  ____|   / __ \\    / __ \\   |  __ \\" << endl << " | | ___   | |  | |  | |  | |  | |  | |" << endl << " | ||_  |  | |  | |  | |  | |  | |  | |" << endl << " | |__| |  | |__| |  | |__| |  | |__| | " << endl << " |______|   \\____/    \\____/   |_____/ " << endl << "                                        " << endl << "                                        " << endl;
		print("GOOD JOB");
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				clear();
				return;
			}
		}
	}
	void developer(){
		clear();
		string mi;
		print("欢迎来到开发者模式");
		cout << "请输入密码: ";
		cout.flush();
		getline(mi);
		if(to_hash(mi) == 12386266893725306769ull){
			hack();
		}else{
			lower_hack();
		}
	}
}
#endif