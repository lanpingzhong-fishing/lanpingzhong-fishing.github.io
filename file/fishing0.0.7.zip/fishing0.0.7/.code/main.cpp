// #include<hashtable.h>
// #include<iostream>
// #include<fstream>
// #include<iomanip>
// #include<ctime>
// using std::cin;
// using std::cout;
// using std::ostream;
// using std::string;
// using std::to_string;
// using std::ifstream;
// using std::ofstream;
// using std::hash;
// using std::setw; 
#include"variate.h"
#include"color.h"
#include"base64.h"
#include"fishing.h"
#include"shop.h"
#include"chp.h"
#include"tool.h"
#include"setting.h"
#include"function.h"
int main(){
	srand(time(0));
	system("stty raw");
	system("stty -echo");
	clear();
	printa("欢迎来到自助钓鱼系统。");
	printa("你可以在这里钓鱼。");
	printa("升级装备可以让钓鱼效率更高。");
	while(true){
		clear();
		print("1.开始钓鱼, 2.进入商店, 3.存档, 4.读档, 5.设置自动保存, 6.开发者模式, 7.设置, 8.退出, 其他输入无效。");
		print("只用输入编号", 0.01);
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}
			if(type == '1'){
				clear();
				fishing::fishing();
				sleep(0.5);
				break;
			}else if(type == '2'){
				clear();
				shop::shop();
				break;
			}else if(type == '3'){
				clear();
				checkpoint::save();
				break;
			}else if(type == '4'){
				clear();
				checkpoint::read();
				break;
			}else if(type == '5'){
				clear();
				checkpoint::set_auto_save();
				break;
			}else if(type == '6'){
				clear();
				tool::developer();
				break;
			}else if(type == '7'){
				clear();
				setting::setting();
				break;
			}else if(type == '8'){
				clear();
				system("stty cooked");
				system("stty echo");
				return 0;
			}
		}
		checkpoint::savechpnp("last", false);
		shop::check_fishing();
		checkpoint::auto_save();
		sleep(1);
	}
}
