#ifndef error_defined
#define error_defined
#include<hashtable.h>
#include<iostream>
#include<iomanip>
#include<string>
using std::cout;
using std::setw; 
using std::hash;
using std::string;
using std::ostream;
using std::to_string;
#include"function.h"
void error(string s){
    while(s.length() < 13){
        s = ' ' + s;
        s = s + ' ';
    }
    if(s.length() & 1){
        s = s + ' ';
    }
    for(int i = 0; i <= 10; i++){
        string s2;
        for(int j = 0; j < i; j++){
            s2 += '=';
        }
        for(int j = i; j < 10; j++){
            s2 += '-';
        }
        clear();
        cout << "+--------------+" << endl << "|              |" << endl << "|" << s << "|" << endl << "|  " << s2 << "  |" << endl << "+--------------+" << endl;
        sleep(0.1);
    }
    bool rand = random(1, 5) <= 1;
    if(rand){
        string s2 = "1234567890-=_+qwertyuiop[]{}QWERTYUIOPasdfghjklASDFGHJKLzxcvbnmzxcvbnmZXCVBNNM";
        int i = random(0, s2.length() - 1);
        print((string)"加载失败, 输入" + s2[i] + "重试");
        char c = getch();
        if(c == s2[i]){
            error(s);
        }else{
            clear();
            cout << "\033[31;1merr:兄弟，别挂机啊\033[m" << endl;
            exit(0);
        }
    }else{
        printa("加载成功");
    }
}
#endif