#ifndef error_defined
#define error_defined
#include<hashtable.h>
#include<iostream>
#include<iomanip>
#include<string>
using std::cout;
using std::setw; 
using std::hash;
using std::string;
using std::ostream;
using std::to_string;
#include"function.h"
bool error(string s){
    while(s.length() < 13){
        s = ' ' + s;
        s = s + ' ';
    }
    if(s.length() & 1){
        s = s + ' ';
    }
    for(int i = 0; i <= 10; i++){
        string s2;
        s2 += "\033[32;1m";
        for(int j = 0; j < i; j++){
            s2 += '=';
        }
        s2 += "\033[m";
        for(int j = i; j < 10; j++){
            s2 += '-';
        }
        clear();
        cout << "+--------------+" << endl << "|              |" << endl << "|" << s << "|" << endl << "|  " << s2 << "  |" << endl << "+--------------+" << endl;
        sleept(0.1);
    }
    bool rand = random(1, 5) <= 1;
    if(rand){
        for(int i = 0; i <= 10; i++){
            string s2;
            for(int j = 0; j < i; j++){
                s2 += '-';
            }
            s2 += "\033[32;1m";
            for(int j = i; j < 10; j++){
                s2 += '=';
            }
            s2 += "\033[m";
            clear();
            cout << "+--------------+" << endl << "|              |" << endl << "|" << s << "|" << endl << "|  " << s2 << "  |" << endl << "+--------------+" << endl;
            sleept(0.1);
        }
        for(int i = 0; i <= 10; i++){
            string s2;
            s2 += "\033[31m";
            for(int j = 0; j < i; j++){
                s2 += '=';
            }
            s2 += "\033[m";
            for(int j = i; j < 10; j++){
                s2 += '-';
            }
            clear();
            cout << "+--------------+" << endl << "|              |" << endl << "|" << s << "|" << endl << "|  " << s2 << "  |" << endl << "+--------------+" << endl;
            sleept(0.1);
        }
        string s2 = "1234567890-=_+qwertyuiop[]{}QWERTYUIOPasdfghjklASDFGHJKLzxcvbnmzxcvbnmZXCVBNNM";
        int i = random(0, s2.length() - 1);
        print((string)"加载失败, 输入" + s2[i] + "重试");
        char c = getch();
        if(c == s2[i]){
            return error(s);
        }else{
            clear();
            printa("按键错误, 请注意大小写并重新尝试"); 
            clear();
            return false;
        }
    }else{
        printa("加载成功");
        clear();
        return true;
    }
}
#endif